<?php
// Only process POST requests.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data.
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $message = trim($_POST["message"]);

    // Very basic validation.
    if (empty($name) || empty($email) || empty($phone) || empty($message)) {
        die("Please fill in all fields.");
    }

    // Database connection parameters.
    $servername = "localhost";
    $username = "root"; // Replace with your MySQL username.
    $password = ""; // Replace with your MySQL password.
    $dbname   = "unique_contact_db"; // Database name.

    // Create connection.
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection.
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare an INSERT query using prepared statements.
    $stmt = $conn->prepare("INSERT INTO unique_contacts (name, email, phone, message) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ssss", $name, $email, $phone, $message);

    // Execute the query.
    if ($stmt->execute()) {
        echo "Thank you for contacting us!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close resources.
    $stmt->close();
    $conn->close();
} else {
    // Not a POST request.
    header("Location: contact.html");
    exit();
}
?>
