-- Create the database (if not already created)
CREATE DATABASE IF NOT EXISTS gym;
USE gym;

-- Create the newsletter table
CREATE TABLE IF NOT EXISTS newsletter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
