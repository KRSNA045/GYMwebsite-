<?php
// Database connection details (adjust these for your setup)
$servername = "localhost";
$username   = "root";      // Replace with your DB username
$password   = "";          // Replace with your DB password
$dbname     = "gym";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection and show error if connection fails
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Retrieve the email value from the form
    // Make sure the input field in your HTML has name="email"
    $email = trim($_POST['email']);

    // Validate the email address format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit;
    }

    // Prepare an SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO newsletter (email) VALUES (?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind the email parameter to the SQL query
    $stmt->bind_param("s", $email);

    // Execute the query and give feedback
    if ($stmt->execute()) {
        echo "Subscription successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
