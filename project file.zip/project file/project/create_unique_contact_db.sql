-- Create a unique database
CREATE DATABASE IF NOT EXISTS unique_contact_db;

-- Use the new database
USE unique_contact_db;

-- Create the table for storing contact form submissions
CREATE TABLE IF NOT EXISTS unique_contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
