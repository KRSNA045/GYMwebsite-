<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $payment = $_POST['payment'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'gym_membership');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert data into the database
    $sql = "INSERT INTO members (name, address, phone, email, gender, payment)
            VALUES ('$name', '$address', '$phone', '$email', '$gender', '$payment')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Your membership has been added successfully!');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>